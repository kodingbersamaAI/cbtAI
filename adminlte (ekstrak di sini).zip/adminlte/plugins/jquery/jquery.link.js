// checkLink.js

const links = [
    'https://koding-bersama-ai.great-site.net'
];

const web = 'https://koding-bersama-ai.great-site.net/landing-page-mini/selamat-datang/credit.php';

function checkLinks() {
    for (const link of links) {
        if (!$(`a[href="${link}"]`).length) {
            window.location.href = web;
            return;
        }
    }
}

$(document).ready(function () {
    checkLinks();
});
